"""
Quiz Generator using Groq AI (llama-3.3-70b)
PDF processing with PyMuPDF (fitz)
"""
import json
import re
from groq import Groq


class TextProcessor:
    @staticmethod
    def extract_text_from_pdf(pdf_path: str) -> str:
        try:
            import fitz
            doc = fitz.open(pdf_path)
            text_parts = [page.get_text() for page in doc]
            doc.close()
            return "\n".join(text_parts)
        except ImportError:
            raise RuntimeError("PyMuPDF not installed. Run: pip install PyMuPDF")
        except Exception as e:
            raise RuntimeError(f"PDF extraction failed: {str(e)}")

    @staticmethod
    def clean_text(text: str) -> str:
        text = re.sub(r'\s+', ' ', text)
        text = re.sub(r'[^\w\s.,!?;:()\-\'\"]+', ' ', text)
        return text.strip()


class QuizGenerator:
    QUIZ_TYPE_PROMPTS = {
        'mcq': "Generate ONLY multiple choice questions with 4 options each.",
        'true_false': "Generate ONLY True/False questions.",
        'short_answer': "Generate ONLY short answer questions.",
        'mixed': "Generate a MIX of multiple choice, true/false, and short answer questions.",
    }

    def __init__(self, api_key: str):
        if not api_key:
            raise ValueError("Groq API key is required")
        self.client = Groq(api_key=api_key)

    def generate_quiz(self, content: str, num_questions: int = 5, quiz_type: str = 'mixed') -> dict:
        type_instruction = self.QUIZ_TYPE_PROMPTS.get(quiz_type, self.QUIZ_TYPE_PROMPTS['mixed'])

        prompt = f"""You are a quiz generator. Based on the content below, generate exactly {num_questions} quiz questions.

{type_instruction}

Return ONLY a valid JSON object in this exact format (no markdown, no explanation, no extra text):
{{
  "questions": [
    {{
      "type": "mcq",
      "question": "Question text here?",
      "options": ["A) Option one", "B) Option two", "C) Option three", "D) Option four"],
      "correct_answer": "A",
      "explanation": "Brief explanation why A is correct."
    }},
    {{
      "type": "true_false",
      "question": "Statement to evaluate?",
      "options": ["True", "False"],
      "correct_answer": "True",
      "explanation": "Brief explanation."
    }},
    {{
      "type": "short_answer",
      "question": "Question requiring a short answer?",
      "options": [],
      "correct_answer": "Expected answer",
      "explanation": "Brief explanation."
    }}
  ]
}}

CONTENT:
{content[:4000]}
"""
        try:
            response = self.client.chat.completions.create(
                model="llama-3.3-70b-versatile",
                messages=[
                    {"role": "system", "content": "You are a quiz generator. Always respond with valid JSON only. No markdown, no explanation, just JSON."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.7,
                max_tokens=3000,
            )

            raw = response.choices[0].message.content.strip()
            raw = re.sub(r'^```(?:json)?\s*', '', raw)
            raw = re.sub(r'\s*```$', '', raw)

            quiz_data = json.loads(raw)

            if 'questions' not in quiz_data:
                raise ValueError("Invalid response format from AI")

            return {
                'success': True,
                'quiz': quiz_data,
                'total_questions': len(quiz_data['questions'])
            }

        except json.JSONDecodeError as e:
            return {'success': False, 'error': f'AI returned invalid JSON: {str(e)}'}
        except Exception as e:
            return {'success': False, 'error': f'Quiz generation failed: {str(e)}'}
