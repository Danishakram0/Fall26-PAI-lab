"""
History management for quiz performance tracking
"""
import json
import os
from datetime import datetime
from pathlib import Path


class HistoryManager:
    """Manages user quiz history with persistent storage"""
    
    def __init__(self, history_file='data/history.json'):
        self.history_file = history_file
        self._ensure_history_dir()
        self._load_history()
    
    def _ensure_history_dir(self):
        """Create data directory if it doesn't exist"""
        Path(os.path.dirname(self.history_file) or '.').mkdir(parents=True, exist_ok=True)
    
    def _load_history(self):
        """Load history from file"""
        if os.path.exists(self.history_file):
            try:
                with open(self.history_file, 'r') as f:
                    self.data = json.load(f)
            except Exception:
                self.data = {'quizzes': []}
        else:
            self.data = {'quizzes': []}
    
    def _save_history(self):
        """Save history to file"""
        try:
            with open(self.history_file, 'w') as f:
                json.dump(self.data, f, indent=2)
        except Exception as e:
            raise RuntimeError(f"Failed to save history: {str(e)}")
    
    def add_quiz_attempt(self, topic: str, score: int, total: int, percentage: float) -> bool:
        """
        Add a new quiz attempt to history
        
        Args:
            topic: Topic/title of the quiz
            score: Number of correct answers
            total: Total number of questions
            percentage: Percentage score
            
        Returns:
            True if successfully added, False otherwise
        """
        try:
            quiz_entry = {
                'topic': topic,
                'score': score,
                'total': total,
                'percentage': round(percentage, 1),
                'timestamp': datetime.now().isoformat(),
                'date': datetime.now().strftime('%b %d, %Y'),
                'time': datetime.now().strftime('%I:%M %p')
            }
            self.data['quizzes'].append(quiz_entry)
            self._save_history()
            return True
        except Exception as e:
            raise RuntimeError(f"Failed to add quiz attempt: {str(e)}")
    
    def get_all_history(self) -> list:
        """Get all quiz history sorted by timestamp (newest first)"""
        try:
            quizzes = self.data.get('quizzes', [])
            # Sort by timestamp, newest first
            return sorted(quizzes, key=lambda x: x.get('timestamp', ''), reverse=True)
        except Exception as e:
            raise RuntimeError(f"Failed to retrieve history: {str(e)}")
    
    def get_statistics(self) -> dict:
        """Get overall statistics from history"""
        quizzes = self.data.get('quizzes', [])
        if not quizzes:
            return {
                'total_quizzes': 0,
                'average_percentage': 0,
                'total_score': 0,
                'total_questions': 0
            }
        
        total_score = sum(q.get('score', 0) for q in quizzes)
        total_questions = sum(q.get('total', 0) for q in quizzes)
        avg_percentage = (sum(q.get('percentage', 0) for q in quizzes) / len(quizzes)) if quizzes else 0
        
        return {
            'total_quizzes': len(quizzes),
            'average_percentage': round(avg_percentage, 1),
            'total_score': total_score,
            'total_questions': total_questions
        }
    
    def clear_history(self) -> bool:
        """Clear all history"""
        try:
            self.data = {'quizzes': []}
            self._save_history()
            return True
        except Exception as e:
            raise RuntimeError(f"Failed to clear history: {str(e)}")
