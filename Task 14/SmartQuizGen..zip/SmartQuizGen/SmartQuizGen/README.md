# SmartQuizGen

An AI-powered quiz generation application built with Flask and Groq API.

## Features

- **PDF & TXT File Support**: Upload PDF or TXT files to extract content
- **AI-Powered Quiz Generation**: Generate quizzes automatically using Groq's Llama model
- **Multiple Question Types**: 
  - Multiple Choice Questions (MCQ)
  - True/False Questions
  - Short Answer Questions
  - Mixed Question Types
- **Answer Verification**: Check answers and get detailed explanations
- **Quiz History**: Track your quiz attempts

## Technologies

- **Backend**: Flask 3.0.3
- **AI Model**: Groq API (llama-3.3-70b-versatile)
- **PDF Processing**: PyMuPDF 1.24.9
- **Environment Management**: python-dotenv 1.0.1

## Installation

1. Clone the repository:
```bash
git clone https://github.com/Danishakram0/Fall26-PAI-lab-project-.git
cd SmartQuizGen
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Set up environment variables:
```bash
cp .env.example .env
# Add your GROQ_API_KEY to .env
```

4. Run the application:
```bash
python run.py
```

The application will be available at `http://localhost:5000`

## Usage

1. Open your browser and navigate to `http://localhost:5000`
2. Either paste text directly or upload a PDF/TXT file
3. Select quiz type and number of questions
4. Generate the quiz
5. Answer the questions
6. Check your results with explanations

## Project Structure

```
SmartQuizGen/
├── app/
│   ├── templates/
│   │   └── index.html
│   ├── static/
│   │   ├── css/
│   │   └── js/
│   └── __init__.py
├── utils/
│   ├── quiz_generator.py
│   ├── history.py
│   └── __init__.py
├── data/
│   └── history.json
├── app.py
├── config.py
├── requirements.txt
└── run.py
```

## License

This project is created for PAI Lab (Spring 2026 Semester).
