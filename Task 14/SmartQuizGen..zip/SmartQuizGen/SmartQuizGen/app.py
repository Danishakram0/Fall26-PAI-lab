import os
from flask import Flask, render_template, request, jsonify
from config import config
from utils.quiz_generator import QuizGenerator, TextProcessor


def create_app(config_name='development'):
    app = Flask(__name__,
                template_folder='app/templates',
                static_folder='app/static')

    app.config.from_object(config[config_name])

    quiz_gen = QuizGenerator(app.config.get('GROQ_API_KEY'))

    @app.route('/')
    def index():
        return render_template('index.html')

    @app.route('/api/generate-quiz', methods=['POST'])
    def generate_quiz():
        try:
            data = request.get_json()
            if not data:
                return jsonify({'success': False, 'error': 'No data provided'}), 400

            content = data.get('content', '').strip()
            num_questions = int(data.get('num_questions', 5))
            quiz_type = data.get('quiz_type', 'mixed')

            if not content:
                return jsonify({'success': False, 'error': 'Content is required'}), 400
            if len(content) < 50:
                return jsonify({'success': False, 'error': 'Content too short. Provide at least 50 characters.'}), 400

            result = quiz_gen.generate_quiz(
                content,
                num_questions=min(num_questions, 20),
                quiz_type=quiz_type
            )
            return jsonify(result), 200 if result['success'] else 400

        except Exception as e:
            return jsonify({'success': False, 'error': f'Server error: {str(e)}'}), 500

    @app.route('/api/process-file', methods=['POST'])
    def process_file():
        try:
            if 'file' not in request.files:
                return jsonify({'success': False, 'error': 'No file provided'}), 400

            file = request.files['file']
            if file.filename == '':
                return jsonify({'success': False, 'error': 'No file selected'}), 400

            filename = file.filename.lower()

            if filename.endswith('.pdf'):
                temp_path = f'/tmp/{file.filename}'
                file.save(temp_path)
                try:
                    text = TextProcessor.extract_text_from_pdf(temp_path)
                finally:
                    if os.path.exists(temp_path):
                        os.remove(temp_path)
            elif filename.endswith('.txt'):
                text = file.read().decode('utf-8')
            else:
                return jsonify({'success': False, 'error': 'Unsupported file type. Use PDF or TXT.'}), 400

            text = TextProcessor.clean_text(text)

            if not text or len(text) < 50:
                return jsonify({'success': False, 'error': 'Could not extract enough text from file.'}), 400

            return jsonify({
                'success': True,
                'text': text,
                'word_count': len(text.split())
            }), 200

        except RuntimeError as e:
            return jsonify({'success': False, 'error': str(e)}), 400
        except Exception as e:
            return jsonify({'success': False, 'error': f'Error processing file: {str(e)}'}), 500

    @app.route('/api/check-answers', methods=['POST'])
    def check_answers():
        try:
            data = request.get_json()
            if not data:
                return jsonify({'success': False, 'error': 'No data provided'}), 400

            questions = data.get('quiz', {}).get('questions', [])
            user_answers = data.get('answers', {})

            if not questions:
                return jsonify({'success': False, 'error': 'No questions in quiz'}), 400

            correct_count = 0
            results = []

            for idx, question in enumerate(questions):
                user_answer = user_answers.get(str(idx), '').strip()
                correct_answer = str(question.get('correct_answer', '')).strip()
                q_type = question.get('type', 'unknown')

                # Normalize MCQ answers
                if q_type == 'mcq' and question.get('options'):
                    if len(correct_answer) == 1 and correct_answer.upper() in 'ABCD':
                        for opt in question.get('options', []):
                            if opt.startswith(correct_answer.upper() + ')'):
                                correct_answer = opt.split(')', 1)[1].strip()
                                break

                    if len(user_answer) > 1 and user_answer[0].upper() in 'ABCD' and user_answer[1] == ')':
                        user_answer = user_answer.split(')', 1)[1].strip()

                is_correct = user_answer.lower() == correct_answer.lower()
                if is_correct:
                    correct_count += 1

                results.append({
                    'question_id': idx,
                    'question': question.get('question'),
                    'user_answer': user_answer,
                    'correct_answer': correct_answer,
                    'is_correct': is_correct,
                    'explanation': question.get('explanation', '')
                })

            total = len(questions)
            percentage = round(correct_count / total * 100, 1) if total > 0 else 0

            return jsonify({
                'success': True,
                'score': correct_count,
                'total': total,
                'percentage': percentage,
                'results': results
            }), 200

        except Exception as e:
            return jsonify({'success': False, 'error': f'Server error: {str(e)}'}), 500

    @app.route('/api/health')
    def health_check():
        return jsonify({'status': 'healthy'}), 200

    @app.errorhandler(404)
    def not_found(e):
        return jsonify({'error': 'Not found'}), 404

    @app.errorhandler(500)
    def server_error(e):
        return jsonify({'error': 'Internal server error'}), 500

    return app


if __name__ == '__main__':
    app = create_app()
    app.run(debug=True)
